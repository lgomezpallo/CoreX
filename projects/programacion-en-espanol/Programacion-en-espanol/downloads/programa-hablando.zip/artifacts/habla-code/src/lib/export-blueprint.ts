import type { AppBlueprint, AppBuilderItem, AppBuilderSection } from '@workspace/api-client-react';

const accents = {
  violet: { main: '#7056c8', soft: '#eeebff' },
  ocean: { main: '#3f78a4', soft: '#e4f1f7' },
  mint: { main: '#3f9277', soft: '#e2f1eb' },
  amber: { main: '#bd7b2e', soft: '#fcf0db' },
} as const;

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (character) => {
    const entities: Record<string, string> = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    };
    return entities[character];
  });
}

function renderItem(item: AppBuilderItem, accent: string) {
  const checked = item.checked;
  return `<button class="item${checked ? ' checked' : ''}" type="button" data-toggle aria-pressed="${checked}">
    <span class="check" aria-hidden="true">✓</span>
    <span class="item-copy"><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.description)}</small></span>
    <span class="item-value" style="color:${accent}">${escapeHtml(item.value)}</span>
  </button>`;
}

function renderSection(section: AppBuilderSection, accent: string, soft: string) {
  let content = '';
  if (section.type === 'stats') {
    content = `<div class="stats">${section.items.map((item) => `<div class="stat" style="background:${soft}"><strong style="color:${accent}">${escapeHtml(item.value)}</strong><span>${escapeHtml(item.title)}</span></div>`).join('')}</div>`;
  } else if (section.type === 'progress') {
    const item = section.items[0];
    const percent = Math.max(0, Math.min(100, Number.parseFloat(item?.value ?? '0') || 0));
    content = item ? `<div class="progress-copy"><strong>${escapeHtml(item.title)}</strong><span style="color:${accent}">${escapeHtml(item.value)}</span></div><div class="progress-track"><span style="width:${percent}%;background:${accent}"></span></div><p class="item-description">${escapeHtml(item.description)}</p>` : '';
  } else if (section.type === 'form') {
    content = `<form class="form" data-form>${section.items.map((item) => `<label>${escapeHtml(item.title)}<input name="${escapeHtml(item.id)}" type="text" placeholder="${escapeHtml(item.description)}"></label>`).join('')}<button class="submit" type="submit" style="background:${accent}">${escapeHtml(section.actionLabel)}</button><p class="form-status" data-status aria-live="polite"></p></form>`;
  } else {
    content = `<div class="items">${section.items.map((item) => renderItem(item, accent)).join('')}</div>`;
  }

  return `<section class="section">
    <div class="section-heading"><div><h2>${escapeHtml(section.title)}</h2><p>${escapeHtml(section.description)}</p></div><span class="action">${escapeHtml(section.actionLabel)}</span></div>
    ${content}
  </section>`;
}

export function buildStandaloneAppHtml(blueprint: AppBlueprint) {
  const accent = accents[blueprint.accentColor] ?? accents.mint;
  const sections = blueprint.sections.map((section) => renderSection(section, accent.main, accent.soft)).join('');

  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="${escapeHtml(blueprint.description)}">
  <title>${escapeHtml(blueprint.title)}</title>
  <style>
    :root{font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#263839;background:#f6f1e8;font-synthesis:none}
    *{box-sizing:border-box}body{margin:0;padding:40px 20px}.app{max-width:760px;margin:auto}
    header{padding:34px 0 26px}header small{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#87918b}
    h1{font-size:clamp(34px,7vw,54px);letter-spacing:-.06em;line-height:1.04;margin:14px 0 10px}
    .subtitle{font-size:19px;font-weight:650;margin:0 0 8px;color:${accent.main}}.description{color:#718079;line-height:1.7;max-width:560px;margin:0}
    .section{padding:20px;margin:16px 0;background:#fffdf9;border:1px solid #e4ddd3;border-radius:20px;box-shadow:0 5px 18px #353c340b}
    .section-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:15px}
    h2{font-size:16px;letter-spacing:-.02em;margin:0 0 5px}.section-heading p,.item-description{font-size:12px;line-height:1.6;color:#909892;margin:0}
    .action{font-size:11px;font-weight:650;color:${accent.main};white-space:nowrap}
    .stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.stat{padding:15px 9px;border-radius:13px;text-align:center}
    .stat strong{display:block;font-size:25px;letter-spacing:-.04em}.stat span{font-size:11px;color:#75817b}
    .item{width:100%;display:flex;align-items:center;gap:12px;padding:13px 0;text-align:left;border:0;border-bottom:1px solid #ebe5dc;background:transparent;cursor:pointer;color:inherit}
    .item:last-child{border-bottom:0}.check{width:21px;height:21px;display:grid;place-items:center;border:1px solid #d6d0c7;border-radius:7px;color:transparent;flex:none}
    .item.checked .check{background:${accent.main};border-color:${accent.main};color:white}.item.checked .item-copy{opacity:.52;text-decoration:line-through}
    .item-copy{flex:1;min-width:0}.item-copy strong,.item-copy small{display:block}.item-copy strong{font-size:13px}.item-copy small{font-size:11px;color:#8b948f;margin-top:4px}
    .item-value{font-size:11px;white-space:nowrap}.progress-copy{display:flex;justify-content:space-between;gap:12px;font-size:13px}
    .progress-track{height:9px;border-radius:999px;background:#ebe7df;overflow:hidden;margin:12px 0 8px}.progress-track span{height:100%;display:block;border-radius:inherit}
    .form label{display:block;margin:12px 0;font-size:12px;font-weight:650}.form input{display:block;width:100%;margin-top:6px;padding:11px 12px;border:1px solid #e1d9cf;border-radius:10px;background:#fffdf9;font:inherit;font-weight:400}.submit{padding:10px 14px;border:0;border-radius:9px;color:white;font-weight:700;cursor:pointer}.form-status{min-height:16px;margin:8px 0 0;color:${accent};font-size:12px}
    footer{padding:25px 0;text-align:center;color:#9ba19c;font-size:11px}
    @media(max-width:520px){body{padding:20px 14px}.section{padding:16px}.stats{gap:6px}.stat{padding:12px 4px}.stat strong{font-size:21px}.item-value{font-size:10px}}
  </style>
</head>
<body>
  <main class="app">
    <header><small>Una app hecha a tu manera</small><h1>${escapeHtml(blueprint.title)}</h1><p class="subtitle">${escapeHtml(blueprint.subtitle)}</p><p class="description">${escapeHtml(blueprint.description)}</p></header>
    ${sections}
    <footer>Creada con Programá hablando</footer>
  </main>
  <script>
    document.addEventListener('click', function(event) {
      const button = event.target.closest('[data-toggle]');
      if (!button) return;
      const checked = button.getAttribute('aria-pressed') !== 'true';
      button.setAttribute('aria-pressed', String(checked));
      button.classList.toggle('checked', checked);
    });
    document.addEventListener('submit', function(event) {
      const form = event.target.closest('[data-form]');
      if (!form) return;
      event.preventDefault();
      form.querySelector('[data-status]').textContent = 'Listo, completaste el formulario en esta vista previa.';
    });
  </script>
</body>
</html>`;
}

export function downloadStandaloneApp(blueprint: AppBlueprint) {
  const fileName = blueprint.title
    .normalize('NFD')
    .replace(/[\\u0300-\\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'mi-app';
  const blob = new Blob([buildStandaloneAppHtml(blueprint)], { type: 'text/html;charset=utf-8' });
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.download = `${fileName}.html`;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}