import ConversationalBuilder from "@/components/conversational-builder";

function App() {
  return <ConversationalBuilder />;
}

export default App;