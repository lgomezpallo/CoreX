import { Router, type IRouter } from "express";
import {
  ExtractWebReferenceBody,
  ExtractWebReferenceResponse,
  GenerateAppBlueprintBody,
  GenerateAppBlueprintResponse,
} from "@workspace/api-zod";
import { generateBlueprintInTasks } from "../lib/builder-orchestrator";
import type { ProviderPreference } from "../lib/llm-providers";
import { extractWebReference } from "../lib/web-reference";

const router: IRouter = Router();

router.post("/builder/reference-url", async (req, res): Promise<void> => {
  const parsed = ExtractWebReferenceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Pegá una dirección web válida." });
    return;
  }

  try {
    const reference = await extractWebReference(parsed.data.url);
    const validated = ExtractWebReferenceResponse.safeParse(reference);
    if (!validated.success) {
      req.log.error({ validationError: validated.error.message }, "Extracted webpage did not match the API contract");
      res.status(502).json({ error: "No pude preparar esa página como referencia." });
      return;
    }
    res.json(validated.data);
  } catch (error) {
    req.log.warn({ err: error }, "Web reference extraction failed");
    res.status(422).json({
      error: error instanceof Error
        ? error.message
        : "No pude leer esa página pública. Revisá el enlace e intentá de nuevo.",
    });
  }
});

router.post("/builder/generate", async (req, res): Promise<void> => {
  const parsed = GenerateAppBlueprintBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Contame en pocas palabras qué querés crear." });
    return;
  }

  const { prompt, previousBlueprint, history, referenceFiles } = parsed.data;
  const providerPreference = (parsed.data.providerPreference ?? "auto") as ProviderPreference;

  try {
    const generatedPayload = await generateBlueprintInTasks({
      prompt,
      previousBlueprint,
      history,
      referenceFiles,
      providerPreference,
    });
    const generated = GenerateAppBlueprintResponse.safeParse(generatedPayload);
    if (!generated.success) {
      req.log.warn(
        { validationError: generated.error.message },
        "Generated app blueprint did not match the API contract",
      );
      res.status(502).json({
        error: "No pude armar una vista previa con ese pedido. Probá describirla de otra forma.",
      });
      return;
    }

    res.json(generated.data);
  } catch (error) {
    req.log.error({ err: error }, "App blueprint generation failed");
    res.status(502).json({
      error: "Ahora no pude generar la app. Intentá de nuevo en un momento.",
    });
  }
});

export default router;