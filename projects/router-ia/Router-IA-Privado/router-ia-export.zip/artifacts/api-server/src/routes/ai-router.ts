import { getAuth } from "@clerk/express";
import { and, asc, desc, eq, ne, type InferInsertModel } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  db,
  aiProvidersTable,
  routerOwnerTable,
  routerTokensTable,
} from "@workspace/db";
import {
  CreateChatCompletionBody,
  CreateChatCompletionResponse,
  CreateProviderBody,
  CreateProviderResponse,
  CreateRouterTokenResponse,
  DeleteProviderParams,
  GetRouterSummaryResponse,
  GetRouterTokenStatusResponse,
  ListProvidersResponse,
  RevokeRouterTokenResponse,
  SendRouterChatBody,
  SendRouterChatResponse,
  TestProviderParams,
  TestProviderResponse,
  UpdateProviderBody,
  UpdateProviderParams,
  UpdateProviderResponse,
} from "@workspace/api-zod";
import {
  createOpenAIChatCompletion,
  decryptApiKey,
  encryptApiKey,
  hashRouterToken,
  issueRouterToken,
  normalizeCustomBaseUrl,
  ProviderRequestError,
  runProviderChat,
  type ChatMessage,
  type ProviderKind,
} from "../lib/ai-router";

const router: IRouter = Router();
type ProviderRow = typeof aiProvidersTable.$inferSelect;
type ProviderInsert = InferInsertModel<typeof aiProvidersTable>;

function currentUserId(req: Request): string | null {
  return getAuth(req).userId ?? null;
}

async function requireClerkUser(
  req: Request,
  res: Response,
): Promise<string | null> {
  const userId = currentUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to use Router IA." });
    return null;
  }

  await db
    .insert(routerOwnerTable)
    .values({ userId })
    .onConflictDoNothing({ target: routerOwnerTable.id });
  const [owner] = await db.select().from(routerOwnerTable).limit(1);
  if (!owner || owner.userId !== userId) {
    res.status(403).json({
      error: "Este Router IA está reservado para la cuenta propietaria.",
    });
    return null;
  }
  return userId;
}

function toPublicProvider(provider: ProviderRow) {
  return {
    id: provider.id,
    name: provider.name,
    kind: provider.kind,
    baseUrl: provider.baseUrl,
    model: provider.model,
    apiKeyPreview: provider.apiKeyPreview,
    isDefault: provider.isDefault,
    status: provider.status,
    lastTestAt: provider.lastTestAt?.toISOString() ?? null,
    createdAt: provider.createdAt.toISOString(),
    updatedAt: provider.updatedAt.toISOString(),
  };
}

function toProviderConfig(provider: ProviderRow) {
  return {
    kind: provider.kind as ProviderKind,
    baseUrl: provider.baseUrl,
    model: provider.model,
    apiKey: decryptApiKey(provider),
  };
}

function safeProviderError(error: unknown): string {
  if (error instanceof ProviderRequestError) {
    return error.message;
  }
  return error instanceof Error ? error.message.slice(0, 260) : "Unexpected error.";
}

async function findProvider(userId: string, id: string): Promise<ProviderRow | null> {
  const [provider] = await db
    .select()
    .from(aiProvidersTable)
    .where(and(eq(aiProvidersTable.userId, userId), eq(aiProvidersTable.id, id)))
    .limit(1);
  return provider ?? null;
}

function tokenPreview(token: string): string {
  return `${token.slice(0, 13)}••••${token.slice(-4)}`;
}

async function selectDefaultProvider(userId: string): Promise<ProviderRow | null> {
  const [provider] = await db
    .select()
    .from(aiProvidersTable)
    .where(and(eq(aiProvidersTable.userId, userId), eq(aiProvidersTable.isDefault, true)))
    .orderBy(desc(aiProvidersTable.updatedAt))
    .limit(1);
  if (provider) {
    return provider;
  }

  const [firstProvider] = await db
    .select()
    .from(aiProvidersTable)
    .where(eq(aiProvidersTable.userId, userId))
    .orderBy(asc(aiProvidersTable.createdAt))
    .limit(1);
  return firstProvider ?? null;
}

async function runChatForUser(
  userId: string,
  messages: ChatMessage[],
  options: {
    providerId?: string | null;
    temperature?: number;
    maxTokens?: number;
    model?: string;
  },
): Promise<{ content: string; provider: string; model: string }> {
  let provider: ProviderRow | null = null;
  if (options.providerId) {
    provider = await findProvider(userId, options.providerId);
  } else {
    provider = await selectDefaultProvider(userId);
  }

  if (!provider) {
    throw new ProviderRequestError(
      options.providerId
        ? "That provider is not configured."
        : "Add a provider and choose a default before chatting.",
      400,
    );
  }

  const response = await runProviderChat(
    toProviderConfig(provider),
    messages,
    {
      temperature: options.temperature,
      maxTokens: options.maxTokens,
      model: options.model,
    },
  );
  return { content: response.content, provider: provider.name, model: response.model };
}

router.get("/providers", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;

  const providers = await db
    .select()
    .from(aiProvidersTable)
    .where(eq(aiProvidersTable.userId, userId))
    .orderBy(desc(aiProvidersTable.updatedAt));
  res.setHeader("Cache-Control", "no-store");
  res.json(ListProvidersResponse.parse(providers.map(toPublicProvider)));
});

router.post("/providers", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;

  const parsed = CreateProviderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  let baseUrl: string | null = null;
  if (parsed.data.kind === "openai-compatible") {
    try {
      if (!parsed.data.baseUrl) {
        res.status(400).json({ error: "Enter an HTTPS API address." });
        return;
      }
      baseUrl = normalizeCustomBaseUrl(parsed.data.baseUrl);
    } catch (error) {
      res.status(400).json({ error: safeProviderError(error) });
      return;
    }
  }

  const [existing] = await db
    .select({ id: aiProvidersTable.id })
    .from(aiProvidersTable)
    .where(eq(aiProvidersTable.userId, userId))
    .limit(1);
  const makeDefault = parsed.data.isDefault || !existing;
  const encrypted = encryptApiKey(parsed.data.apiKey);

  const created = await db.transaction(async (tx) => {
    if (makeDefault) {
      await tx
        .update(aiProvidersTable)
        .set({ isDefault: false })
        .where(eq(aiProvidersTable.userId, userId));
    }
    const [provider] = await tx
      .insert(aiProvidersTable)
      .values({
        userId,
        name: parsed.data.name.trim(),
        kind: parsed.data.kind,
        baseUrl,
        model: parsed.data.model.trim(),
        ...encrypted,
        isDefault: makeDefault,
      })
      .returning();
    return provider;
  });

  if (!created) {
    res.status(500).json({ error: "The provider could not be saved." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.status(201).json(CreateProviderResponse.parse(toPublicProvider(created)));
});

router.patch("/providers/:id", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;

  const params = UpdateProviderParams.safeParse(req.params);
  const parsed = UpdateProviderBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: params.success
        ? (parsed.error?.message ?? "Invalid provider changes.")
        : (params.error?.message ?? "Invalid provider ID."),
    });
    return;
  }

  const provider = await findProvider(userId, params.data.id);
  if (!provider) {
    res.status(404).json({ error: "Provider not found." });
    return;
  }
  if (Object.keys(parsed.data).length === 0) {
    res.status(400).json({ error: "No provider changes were supplied." });
    return;
  }

  const patch: Partial<ProviderInsert> = { updatedAt: new Date() };
  if (parsed.data.name !== undefined) patch.name = parsed.data.name.trim();
  if (parsed.data.model !== undefined) patch.model = parsed.data.model.trim();
  if (parsed.data.apiKey !== undefined) {
    Object.assign(patch, encryptApiKey(parsed.data.apiKey));
    patch.status = "untested";
    patch.lastTestAt = null;
  }
  if (provider.kind === "openai-compatible" && parsed.data.baseUrl !== undefined) {
    try {
      patch.baseUrl = parsed.data.baseUrl
        ? normalizeCustomBaseUrl(parsed.data.baseUrl)
        : null;
      if (!patch.baseUrl) {
        res.status(400).json({ error: "Enter an HTTPS API address." });
        return;
      }
    } catch (error) {
      res.status(400).json({ error: safeProviderError(error) });
      return;
    }
  }

  const updated = await db.transaction(async (tx) => {
    if (parsed.data.isDefault) {
      await tx
        .update(aiProvidersTable)
        .set({ isDefault: false })
        .where(eq(aiProvidersTable.userId, userId));
      patch.isDefault = true;
    } else if (parsed.data.isDefault === false && provider.isDefault) {
      patch.isDefault = false;
    }

    const [row] = await tx
      .update(aiProvidersTable)
      .set(patch)
      .where(
        and(
          eq(aiProvidersTable.userId, userId),
          eq(aiProvidersTable.id, params.data.id),
        ),
      )
      .returning();

    if (parsed.data.isDefault === false && provider.isDefault) {
      const [fallback] = await tx
        .select({ id: aiProvidersTable.id })
        .from(aiProvidersTable)
        .where(
          and(
            eq(aiProvidersTable.userId, userId),
            ne(aiProvidersTable.id, params.data.id),
          ),
        )
        .orderBy(asc(aiProvidersTable.createdAt))
        .limit(1);
      if (fallback) {
        await tx
          .update(aiProvidersTable)
          .set({ isDefault: true })
          .where(eq(aiProvidersTable.id, fallback.id));
      } else {
        await tx
          .update(aiProvidersTable)
          .set({ isDefault: true })
          .where(eq(aiProvidersTable.id, params.data.id));
      }
    }
    return row;
  });

  res.setHeader("Cache-Control", "no-store");
  res.json(UpdateProviderResponse.parse(toPublicProvider(updated)));
});

router.delete("/providers/:id", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;
  const params = DeleteProviderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const deleted = await db.transaction(async (tx) => {
    const [provider] = await tx
      .delete(aiProvidersTable)
      .where(
        and(
          eq(aiProvidersTable.userId, userId),
          eq(aiProvidersTable.id, params.data.id),
        ),
      )
      .returning();

    if (provider?.isDefault) {
      const [fallback] = await tx
        .select({ id: aiProvidersTable.id })
        .from(aiProvidersTable)
        .where(eq(aiProvidersTable.userId, userId))
        .orderBy(asc(aiProvidersTable.createdAt))
        .limit(1);
      if (fallback) {
        await tx
          .update(aiProvidersTable)
          .set({ isDefault: true })
          .where(eq(aiProvidersTable.id, fallback.id));
      }
    }
    return provider;
  });

  if (!deleted) {
    res.status(404).json({ error: "Provider not found." });
    return;
  }
  res.status(204).send();
});

router.post("/providers/:id/test", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;
  const params = TestProviderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const provider = await findProvider(userId, params.data.id);
  if (!provider) {
    res.status(404).json({ error: "Provider not found." });
    return;
  }

  const startedAt = Date.now();
  let result: { success: boolean; message: string; model: string; latencyMs: number };
  try {
    await runProviderChat(
      toProviderConfig(provider),
      [{ role: "user", content: "Reply with OK." }],
      { maxTokens: 8 },
    );
    result = {
      success: true,
      message: "Connection is working.",
      model: provider.model,
      latencyMs: Date.now() - startedAt,
    };
  } catch (error) {
    result = {
      success: false,
      message: safeProviderError(error),
      model: provider.model,
      latencyMs: Date.now() - startedAt,
    };
    req.log.warn(
      { providerId: provider.id, message: result.message },
      "Provider connection test failed",
    );
  }

  const [updated] = await db
    .update(aiProvidersTable)
    .set({
      status: result.success ? "connected" : "error",
      lastTestAt: new Date(),
      updatedAt: new Date(),
    })
    .where(
      and(
        eq(aiProvidersTable.userId, userId),
        eq(aiProvidersTable.id, provider.id),
      ),
    )
    .returning();

  res.setHeader("Cache-Control", "no-store");
  res.json(
    TestProviderResponse.parse({
      ...result,
      model: updated?.model ?? provider.model,
    }),
  );
});

router.get("/router/summary", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;

  const providers = await db
    .select()
    .from(aiProvidersTable)
    .where(eq(aiProvidersTable.userId, userId))
    .orderBy(desc(aiProvidersTable.updatedAt));
  const [token] = await db
    .select({ id: routerTokensTable.id })
    .from(routerTokensTable)
    .where(eq(routerTokensTable.userId, userId))
    .limit(1);
  const defaultProvider =
    providers.find((provider) => provider.isDefault) ?? providers[0] ?? null;

  res.setHeader("Cache-Control", "no-store");
  res.json(
    GetRouterSummaryResponse.parse({
      providerCount: providers.length,
      defaultProvider: defaultProvider
        ? toPublicProvider(defaultProvider)
        : null,
      hasToken: Boolean(token),
    }),
  );
});

router.post("/router/chat", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;
  const parsed = SendRouterChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const result = await runChatForUser(
      userId,
      parsed.data.messages as ChatMessage[],
      {
        providerId: parsed.data.providerId,
        temperature: parsed.data.temperature,
        maxTokens: parsed.data.maxTokens,
      },
    );
    res.json(SendRouterChatResponse.parse(result));
  } catch (error) {
    const status =
      error instanceof ProviderRequestError ? error.statusCode : 500;
    res.status(status).json({ error: safeProviderError(error) });
  }
});

router.get("/router/token", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;
  const [token] = await db
    .select()
    .from(routerTokensTable)
    .where(eq(routerTokensTable.userId, userId))
    .limit(1);

  res.setHeader("Cache-Control", "no-store");
  res.json(
    GetRouterTokenStatusResponse.parse({
      active: Boolean(token),
      preview: token?.tokenPreview ?? null,
      createdAt: token?.createdAt.toISOString() ?? null,
    }),
  );
});

router.post("/router/token", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;
  const token = issueRouterToken();

  const [issued] = await db.transaction(async (tx) => {
    await tx
      .delete(routerTokensTable)
      .where(eq(routerTokensTable.userId, userId));
    return tx
      .insert(routerTokensTable)
      .values({
        userId,
        tokenHash: hashRouterToken(token),
        tokenPreview: tokenPreview(token),
      })
      .returning();
  });

  res.setHeader("Cache-Control", "no-store");
  res.status(201).json(
    CreateRouterTokenResponse.parse({
      token,
      preview: issued.tokenPreview,
      createdAt: issued.createdAt.toISOString(),
    }),
  );
});

router.delete("/router/token", async (req, res): Promise<void> => {
  const userId = await requireClerkUser(req, res);
  if (!userId) return;
  await db
    .delete(routerTokensTable)
    .where(eq(routerTokensTable.userId, userId));
  RevokeRouterTokenResponse.parse(undefined);
  res.status(204).send();
});

router.post("/v1/chat/completions", async (req, res): Promise<void> => {
  const authorization = req.header("authorization") ?? "";
  const match = authorization.match(/^Bearer (ria_live_[A-Za-z0-9_-]+)$/);
  if (!match) {
    res.status(401).json({
      error: { message: "A valid Router IA bearer token is required." },
    });
    return;
  }

  const [token] = await db
    .select({ userId: routerTokensTable.userId })
    .from(routerTokensTable)
    .where(eq(routerTokensTable.tokenHash, hashRouterToken(match[1])))
    .limit(1);
  if (!token) {
    res.status(401).json({
      error: { message: "A valid Router IA bearer token is required." },
    });
    return;
  }

  const parsed = CreateChatCompletionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: { message: parsed.error.message } });
    return;
  }
  if (parsed.data.stream) {
    res.status(400).json({
      error: { message: "Streaming is not supported by this Router IA version." },
    });
    return;
  }

  try {
    const modelName = parsed.data.model?.trim();
    const availableProviders = await db
      .select()
      .from(aiProvidersTable)
      .where(eq(aiProvidersTable.userId, token.userId))
      .orderBy(desc(aiProvidersTable.updatedAt));
    const matchingProvider = modelName
      ? availableProviders.find((provider) => provider.model === modelName)
      : undefined;
    const provider = matchingProvider ?? (await selectDefaultProvider(token.userId));
    if (!provider) {
      res.status(400).json({
        error: { message: "Add a provider and choose a default before chatting." },
      });
      return;
    }

    const result = await runProviderChat(
      toProviderConfig(provider),
      parsed.data.messages as ChatMessage[],
      {
        temperature: parsed.data.temperature,
        maxTokens: parsed.data.max_tokens,
        model: modelName,
      },
    );
    res.setHeader("Cache-Control", "no-store");
    res.json(
      CreateChatCompletionResponse.parse(createOpenAIChatCompletion(result)),
    );
  } catch (error) {
    const message = safeProviderError(error);
    req.log.warn({ message }, "Router provider request failed");
    res.status(502).json({ error: { message } });
  }
});

export default router;