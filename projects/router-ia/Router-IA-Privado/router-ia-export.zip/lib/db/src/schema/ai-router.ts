import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  index,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const aiProvidersTable = pgTable(
  "ai_providers",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: text("user_id").notNull(),
    name: text("name").notNull(),
    kind: text("kind").notNull(),
    baseUrl: text("base_url"),
    model: text("model").notNull(),
    apiKeyCiphertext: text("api_key_ciphertext").notNull(),
    apiKeyIv: text("api_key_iv").notNull(),
    apiKeyTag: text("api_key_tag").notNull(),
    apiKeyPreview: text("api_key_preview").notNull(),
    isDefault: boolean("is_default").notNull().default(false),
    status: text("status").notNull().default("untested"),
    lastTestAt: timestamp("last_test_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("ai_providers_user_idx").on(table.userId),
    index("ai_providers_user_default_idx").on(table.userId, table.isDefault),
  ],
);

export const insertAiProviderSchema = createInsertSchema(aiProvidersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastTestAt: true,
});
export type InsertAiProvider = z.infer<typeof insertAiProviderSchema>;
export type AiProvider = typeof aiProvidersTable.$inferSelect;

export const routerTokensTable = pgTable(
  "router_tokens",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    tokenHash: text("token_hash").notNull().unique(),
    tokenPreview: text("token_preview").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("router_tokens_user_unique").on(table.userId)],
);

export const routerOwnerTable = pgTable("router_owner", {
  id: text("id").notNull().default("owner").primaryKey(),
  userId: text("user_id").notNull().unique(),
  claimedAt: timestamp("claimed_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertRouterOwnerSchema = createInsertSchema(routerOwnerTable).omit({
  id: true,
  claimedAt: true,
});
export type InsertRouterOwner = z.infer<typeof insertRouterOwnerSchema>;
export type RouterOwner = typeof routerOwnerTable.$inferSelect;

export const insertRouterTokenSchema = createInsertSchema(routerTokensTable).omit({
  id: true,
  createdAt: true,
});
export type InsertRouterToken = z.infer<typeof insertRouterTokenSchema>;
export type RouterToken = typeof routerTokensTable.$inferSelect;