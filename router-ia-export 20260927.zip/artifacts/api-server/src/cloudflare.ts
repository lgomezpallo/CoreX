import { env } from "cloudflare:workers";
import { httpServerHandler } from "cloudflare:node";
import { env as processEnv } from "node:process";

function requiredBinding(name: string, value: string | undefined): string {
  if (!value?.trim()) {
    throw new Error(`Missing required Cloudflare binding: ${name}`);
  }
  return value;
}

// Set the existing Express/Drizzle runtime configuration before loading app.ts,
// because the database pool and Clerk middleware read process.env at import.
processEnv.NODE_ENV = "production";
processEnv.SUPABASE_DATABASE_URL = requiredBinding(
  "HYPERDRIVE",
  env.HYPERDRIVE?.connectionString,
);
processEnv.SESSION_SECRET = requiredBinding(
  "SESSION_SECRET",
  env.SESSION_SECRET,
);
processEnv.CLERK_PUBLISHABLE_KEY = requiredBinding(
  "CLERK_PUBLISHABLE_KEY",
  env.CLERK_PUBLISHABLE_KEY,
);
processEnv.CLERK_SECRET_KEY = requiredBinding(
  "CLERK_SECRET_KEY",
  env.CLERK_SECRET_KEY,
);
processEnv.CLERK_PROXY_ENABLED = env.CLERK_PROXY_ENABLED ?? "false";
if (env.LOG_LEVEL) processEnv.LOG_LEVEL = env.LOG_LEVEL;
if (env.GROQ_API_KEY?.trim()) processEnv.GROQ_API_KEY = env.GROQ_API_KEY;

// Static files are served by Wrangler's assets layer, not Express's filesystem
// middleware. This keeps the same Express app focused on API and health routes.
processEnv.STATIC_DIR = "";

const { default: app } = await import("./app");
app.listen(8787);

export default httpServerHandler({ port: 8787 });
