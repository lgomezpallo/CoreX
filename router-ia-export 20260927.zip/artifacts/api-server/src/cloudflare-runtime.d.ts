declare module "cloudflare:workers" {
  export const env: {
    HYPERDRIVE: { connectionString: string };
    CLERK_PUBLISHABLE_KEY: string;
    CLERK_SECRET_KEY: string;
    SESSION_SECRET: string;
    CLERK_PROXY_ENABLED?: string;
    LOG_LEVEL?: string;
    GROQ_API_KEY?: string;
  };
}

declare module "cloudflare:node" {
  export function httpServerHandler(options: { port: number }): unknown;
}
