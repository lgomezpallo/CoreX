const OPENROUTER_MODELS_URL =
  "https://openrouter.ai/api/v1/models?limit=1000";
const CACHE_TTL_MS = 5 * 60 * 1000;
const MAX_RESPONSE_BYTES = 4_000_000;
const ALLOWED_MODALITIES = new Set(["text", "image", "audio", "video", "file"]);

type RadarModality = "text" | "image" | "audio" | "video" | "file";
type RadarCapability =
  | "chat"
  | "vision"
  | "document"
  | "transcription"
  | "speech"
  | "audio_generation"
  | "video"
  | "image_generation"
  | "coding"
  | "reasoning"
  | "long_context";

export type RadarModel = {
  id: string;
  name: string;
  publisher: string;
  description: string;
  inputModalities: RadarModality[];
  outputModalities: RadarModality[];
  capabilities: RadarCapability[];
  contextLength: number | null;
  pricingVerifiedAt: string;
};

export type RadarCatalog = {
  source: "openrouter";
  checkedAt: string;
  totalModels: number;
  zeroCostModels: number;
  models: RadarModel[];
};

type CacheEntry = {
  expiresAt: number;
  value: RadarCatalog;
};

let catalogCache: CacheEntry | null = null;

function asRecord(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value)
    ? value.filter((item): item is string => typeof item === "string")
    : [];
}

function safeModalities(value: unknown): RadarModality[] {
  return [...new Set(
    stringArray(value).filter((item): item is RadarModality =>
      ALLOWED_MODALITIES.has(item),
    ),
  )];
}

function hasZeroPricing(pricing: unknown): boolean {
  const fields = Object.values(asRecord(pricing));
  return (
    fields.length > 0 &&
    fields.every((field) => {
      if (
        (typeof field !== "string" && typeof field !== "number") ||
        (typeof field === "string" && field.trim() === "")
      ) {
        return false;
      }
      const price = Number(field);
      return Number.isFinite(price) && price === 0;
    })
  );
}

function classifyCapabilities(
  id: string,
  name: string,
  inputModalities: RadarModality[],
  outputModalities: RadarModality[],
  contextLength: number | null,
): RadarCapability[] {
  const capabilities = new Set<RadarCapability>();
  if (inputModalities.includes("text") && outputModalities.includes("text")) {
    capabilities.add("chat");
  }
  if (inputModalities.includes("image")) capabilities.add("vision");
  if (inputModalities.includes("file")) capabilities.add("document");
  if (
    inputModalities.includes("audio") &&
    outputModalities.includes("text")
  ) {
    capabilities.add("transcription");
  }
  if (outputModalities.includes("audio")) {
    capabilities.add("audio_generation");
  }
  if (
    inputModalities.includes("video") ||
    outputModalities.includes("video")
  ) {
    capabilities.add("video");
  }
  if (outputModalities.includes("image")) {
    capabilities.add("image_generation");
  }
  if (contextLength !== null && contextLength >= 128_000) {
    capabilities.add("long_context");
  }

  const searchableName = `${id} ${name}`.toLowerCase();
  if (
    /\b(tts|speech|text[- ]to[- ]speech|voice synthesis)\b/.test(
      searchableName,
    )
  ) {
    capabilities.add("speech");
  }
  if (/(^|[^a-z])(code|coder|coding|dev)([^a-z]|$)/.test(searchableName)) {
    capabilities.add("coding");
  }
  if (
    /(reason|thinking|thinker|deepseek-r1|(^|[^a-z])o[134]([^a-z]|$))/.test(
      searchableName,
    )
  ) {
    capabilities.add("reasoning");
  }

  return [...capabilities];
}

function toRadarModel(rawValue: unknown, checkedAt: string): RadarModel | null {
  const raw = asRecord(rawValue);
  if (typeof raw.id !== "string" || !raw.id.trim()) return null;
  if (!hasZeroPricing(raw.pricing)) return null;

  const architecture = asRecord(raw.architecture);
  const inputModalities = safeModalities(architecture.input_modalities);
  const outputModalities = safeModalities(architecture.output_modalities);
  const contextLength =
    typeof raw.context_length === "number" &&
    Number.isInteger(raw.context_length) &&
    raw.context_length > 0
      ? raw.context_length
      : null;
  const id = raw.id.trim();
  const name =
    typeof raw.name === "string" && raw.name.trim()
      ? raw.name.trim().slice(0, 200)
      : id;
  const description =
    typeof raw.description === "string"
      ? raw.description.trim().slice(0, 1_200)
      : "";

  return {
    id,
    name,
    publisher: id.split("/", 1)[0] || "desconocido",
    description,
    inputModalities,
    outputModalities,
    capabilities: classifyCapabilities(
      id,
      name,
      inputModalities,
      outputModalities,
      contextLength,
    ),
    contextLength,
    pricingVerifiedAt: checkedAt,
  };
}

export async function listZeroCostRadarModels(
  forceRefresh = false,
): Promise<RadarCatalog> {
  const now = Date.now();
  if (!forceRefresh && catalogCache && catalogCache.expiresAt > now) {
    return catalogCache.value;
  }

  let response: Response;
  try {
    response = await fetch(OPENROUTER_MODELS_URL, {
      method: "GET",
      headers: { accept: "application/json" },
      redirect: "error",
      signal: AbortSignal.timeout(12_000),
    });
  } catch {
    throw new Error("No se pudo consultar el catálogo público de modelos.");
  }

  if (!response.ok) {
    throw new Error(
      `El catálogo público respondió con HTTP ${response.status}.`,
    );
  }

  const responseText = await response.text();
  if (responseText.length > MAX_RESPONSE_BYTES) {
    throw new Error("El catálogo público devolvió una respuesta demasiado grande.");
  }

  let payload: Record<string, unknown>;
  try {
    payload = asRecord(JSON.parse(responseText) as unknown);
  } catch {
    throw new Error("El catálogo público devolvió datos ilegibles.");
  }

  if (!Array.isArray(payload.data)) {
    throw new Error("El catálogo público no incluyó una lista de modelos.");
  }

  const checkedAt = new Date().toISOString();
  const models = payload.data
    .map((model) => toRadarModel(model, checkedAt))
    .filter((model): model is RadarModel => model !== null)
    .sort((left, right) => left.name.localeCompare(right.name));
  const totalModels =
    typeof payload.total_count === "number" &&
    Number.isInteger(payload.total_count) &&
    payload.total_count >= 0
      ? payload.total_count
      : payload.data.length;
  const value: RadarCatalog = {
    source: "openrouter",
    checkedAt,
    totalModels,
    zeroCostModels: models.length,
    models,
  };

  catalogCache = {
    expiresAt: now + CACHE_TTL_MS,
    value,
  };
  return value;
}