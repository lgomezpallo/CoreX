import { useMemo, useState } from 'react';
import {
  ArrowRight,
  AudioLines,
  BrainCircuit,
  Check,
  ChevronDown,
  CircleHelp,
  Database,
  FileText,
  Image,
  Layers3,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  TriangleAlert,
  Video,
  X,
} from 'lucide-react';
import {
  useListProviders,
  useListRadarModels,
  type Provider,
  type RadarModel,
} from '@workspace/api-client-react';
import { Link } from 'wouter';

const capabilityLabels: Record<string, string> = {
  chat: 'Chat',
  vision: 'Visión',
  document: 'Documentos',
  transcription: 'Transcripción',
  speech: 'Síntesis de voz',
  audio_generation: 'Generación de audio',
  video: 'Video',
  image_generation: 'Generación de imágenes',
  coding: 'Código',
  reasoning: 'Razonamiento',
  long_context: 'Contexto largo',
  summarization: 'Resumen',
  fast: 'Baja latencia',
};

const modalityIcons = {
  text: FileText,
  image: Image,
  audio: AudioLines,
  video: Video,
  file: Layers3,
} as const;

const modalityLabels: Record<string, string> = {
  text: 'texto',
  image: 'imagen',
  audio: 'audio',
  video: 'video',
  file: 'archivo',
};

function formatRadarDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'fecha no disponible';
  return new Intl.DateTimeFormat('es', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

function formatContext(value: number | null) {
  if (value === null) return 'No publicado';
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value % 1_000_000 === 0 ? 0 : 1)} M`;
  if (value >= 1_000) return `${Math.round(value / 1_000)} k`;
  return value.toLocaleString('es');
}

function RadarSkeleton() {
  return (
    <div className="mx-auto max-w-6xl animate-pulse space-y-6" aria-label="Cargando Radar" data-testid="loading-radar">
      <div className="h-3 w-28 rounded bg-muted" />
      <div className="h-12 w-80 rounded bg-muted" />
      <div className="h-24 rounded-xl bg-muted" />
      <div className="grid gap-4 md:grid-cols-3">
        <div className="h-28 rounded-xl bg-muted" />
        <div className="h-28 rounded-xl bg-muted" />
        <div className="h-28 rounded-xl bg-muted" />
      </div>
      <div className="h-80 rounded-xl bg-muted" />
    </div>
  );
}

function RadarError({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="flex min-h-[460px] items-center justify-center px-4" data-testid="status-radar-error">
      <div className="max-w-md text-center">
        <span className="inline-flex rounded-xl bg-destructive/10 p-3 text-destructive">
          <TriangleAlert size={22} />
        </span>
        <h2 className="mt-4 text-xl font-semibold">Radar no pudo actualizarse</h2>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">
          No pudimos leer el catálogo público en este momento. Tus proveedores y sus credenciales no se modificaron.
        </p>
        <button
          type="button"
          onClick={onRetry}
          data-testid="button-retry-radar"
          className="mt-5 inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-semibold hover:bg-muted"
        >
          <RefreshCw size={15} />
          Intentar de nuevo
        </button>
      </div>
    </div>
  );
}

function CapabilityBadge({ capability, muted = false }: { capability: string; muted?: boolean }) {
  return (
    <span
      className={`inline-flex items-center rounded-md border px-2 py-1 font-mono text-[10px] uppercase tracking-[.08em] ${
        muted
          ? 'border-border bg-background text-muted-foreground'
          : 'border-primary/20 bg-primary/8 text-primary'
      }`}
    >
      {capabilityLabels[capability] ?? capability.replaceAll('_', ' ')}
    </span>
  );
}

function ModalityList({ title, values }: { title: string; values: RadarModel['inputModalities'] }) {
  return (
    <div>
      <div className="field-label">{title}</div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {values.length === 0 ? (
          <span className="text-xs text-muted-foreground">No publicado</span>
        ) : (
          values.map(value => {
            const Icon = modalityIcons[value];
            return (
              <span
                key={value}
                className="inline-flex items-center gap-1.5 rounded-md bg-muted px-2 py-1 text-xs text-muted-foreground"
              >
                <Icon size={12} />
                {modalityLabels[value] ?? value}
              </span>
            );
          })
        )}
      </div>
    </div>
  );
}

function RadarModelRow({ model, index }: { model: RadarModel; index: number }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <article
      className="border-b border-border px-5 py-5 last:border-b-0 md:px-6"
      data-testid={`card-radar-model-${model.id}`}
    >
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex min-w-0 gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-secondary/35 bg-secondary/10 text-secondary-foreground">
            <Sparkles size={17} />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="truncate text-base font-semibold">{model.name}</h3>
              <span className="rounded-full bg-primary/10 px-2 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-[.1em] text-primary">
                $0 publicado
              </span>
            </div>
            <p className="mt-1 truncate font-mono text-[10px] uppercase tracking-[.1em] text-muted-foreground">
              {model.publisher} · {model.id}
            </p>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">
              {model.description || 'El catálogo no publicó una descripción para este modelo.'}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setExpanded(value => !value)}
          aria-expanded={expanded}
          data-testid={`button-toggle-radar-model-${index}`}
          className="inline-flex shrink-0 items-center justify-center gap-2 self-start rounded-lg border border-border px-3 py-2 text-xs font-semibold hover:bg-muted"
        >
          {expanded ? 'Ocultar ficha' : 'Ver ficha'}
          <ChevronDown size={14} className={`transition-transform ${expanded ? 'rotate-180' : ''}`} />
        </button>
      </div>
      <div className="mt-5 grid gap-4 border-t border-border pt-4 sm:grid-cols-3">
        <div>
          <div className="field-label">Contexto</div>
          <div className="mt-2 font-mono text-sm" data-testid={`text-radar-context-${index}`}>
            {formatContext(model.contextLength)} tokens
          </div>
        </div>
        <ModalityList title="Entrada" values={model.inputModalities} />
        <ModalityList title="Salida" values={model.outputModalities} />
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="field-label mr-1">Capacidades detectadas</span>
        {model.capabilities.map(capability => (
          <span key={capability} data-testid={`badge-radar-capability-${model.id}-${capability}`}>
            <CapabilityBadge capability={capability} />
          </span>
        ))}
      </div>
      {expanded && (
        <div
          className="mt-5 grid gap-4 border-t border-dashed border-border bg-background/60 pt-4 text-xs sm:grid-cols-2"
          data-testid={`panel-radar-model-${index}`}
        >
          <div>
            <div className="field-label">Identificador de catálogo</div>
            <code className="mt-2 block break-all font-mono text-muted-foreground">{model.id}</code>
          </div>
          <div>
            <div className="field-label">Precio verificado en</div>
            <time className="mt-2 block text-muted-foreground" dateTime={model.pricingVerifiedAt}>
              {formatRadarDate(model.pricingVerifiedAt)}
            </time>
          </div>
        </div>
      )}
    </article>
  );
}

function CapabilityGapTable({
  models,
  providers,
}: {
  models: RadarModel[];
  providers: Provider[];
}) {
  const catalogCapabilities = useMemo(
    () => Array.from(new Set(models.flatMap(model => model.capabilities))),
    [models],
  );
  const testedProviders = providers.filter(provider => provider.isActive && provider.status === 'connected');
  const testedCapabilities = new Set<string>(testedProviders.flatMap(provider => provider.capabilities));
  const testedCapabilityList = Array.from(testedCapabilities).sort((a, b) => a.localeCompare(b));
  const rows = catalogCapabilities
    .map(capability => ({
      capability,
      models: models.filter(model => model.capabilities.includes(capability)).length,
      tested: testedCapabilities.has(capability),
    }))
    .sort((a, b) => b.models - a.models || a.capability.localeCompare(b.capability));

  return (
    <section className="border border-border bg-card" data-testid="section-radar-capability-gaps">
      <div className="flex flex-col gap-3 border-b border-border px-5 py-5 md:flex-row md:items-end md:justify-between md:px-6">
        <div>
          <div className="flex items-center gap-2">
            <BrainCircuit size={17} className="text-primary" />
            <h2 className="font-semibold">Brecha de capacidades</h2>
          </div>
          <p className="mt-1 max-w-xl text-xs leading-5 text-muted-foreground">
            Contrasta lo que el catálogo detecta con las capacidades declaradas por tus rutas conectadas.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 font-mono text-[9px] uppercase tracking-[.1em] text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" /> catálogo
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-secondary" /> router probado
          </span>
        </div>
      </div>
      <div className="grid gap-3 border-b border-border p-5 md:grid-cols-2 md:p-6">
        <div className="border border-primary/15 bg-primary/5 p-4" data-testid="panel-radar-detected-capabilities">
          <div className="field-label text-primary">Capacidades detectadas en catálogo</div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {catalogCapabilities.length === 0 ? (
              <span className="text-xs text-muted-foreground">Sin capacidades publicadas</span>
            ) : (
              catalogCapabilities.map(capability => <CapabilityBadge key={capability} capability={capability} />)
            )}
          </div>
        </div>
        <div className="border border-secondary/20 bg-secondary/5 p-4" data-testid="panel-radar-tested-capabilities">
          <div className="field-label text-secondary-foreground">Capacidades probadas en Router</div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {testedCapabilityList.length === 0 ? (
              <span className="text-xs text-muted-foreground">No hay una ruta conectada todavía</span>
            ) : (
              testedCapabilityList.map(capability => <CapabilityBadge key={capability} capability={capability} muted />)
            )}
          </div>
        </div>
      </div>
      {rows.length === 0 ? (
        <div className="px-6 py-8 text-sm text-muted-foreground">No hay capacidades publicadas para comparar.</div>
      ) : (
        <div className="grid gap-px bg-border sm:grid-cols-2 xl:grid-cols-3">
          {rows.map(row => (
            <div
              key={row.capability}
              className="bg-card px-5 py-4"
              data-testid={`row-radar-gap-${row.capability}`}
            >
              <div className="flex items-start justify-between gap-3">
                <span className="text-sm font-semibold">{capabilityLabels[row.capability] ?? row.capability}</span>
                <span className="font-mono text-xs text-muted-foreground">{row.models} modelos</span>
              </div>
              <div className="mt-3 flex items-center gap-2 text-[10px]">
                <span className="inline-flex items-center gap-1.5 text-primary">
                  <Check size={13} />
                  Detectada en catálogo
                </span>
                <span className={`ml-auto inline-flex items-center gap-1.5 ${row.tested ? 'text-secondary-foreground' : 'text-muted-foreground'}`}>
                  <span className={`h-1.5 w-1.5 rounded-full ${row.tested ? 'bg-secondary' : 'bg-border'}`} />
                  {row.tested ? 'Probada en Router' : 'Sin ruta probada'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="flex items-start gap-2 border-t border-border px-5 py-4 text-[11px] leading-5 text-muted-foreground md:px-6">
        <CircleHelp size={14} className="mt-0.5 shrink-0 text-primary" />
        <span>
          “Probada en Router” significa que existe una ruta activa que figura como conectada. Radar no envía inferencias ni vuelve a probar modelos.
        </span>
      </div>
    </section>
  );
}

export default function RadarPage() {
  const radarQuery = useListRadarModels();
  const providersQuery = useListProviders();
  const [search, setSearch] = useState('');
  const [capabilityFilter, setCapabilityFilter] = useState('all');
  const [publisherFilter, setPublisherFilter] = useState('all');

  const catalog = radarQuery.data;
  const providers = providersQuery.data ?? [];
  const models = catalog?.models ?? [];
  const publishers = useMemo(
    () => Array.from(new Set(models.map(model => model.publisher))).sort((a, b) => a.localeCompare(b)),
    [models],
  );
  const capabilities = useMemo(
    () => Array.from(new Set(models.flatMap(model => model.capabilities))).sort((a, b) => a.localeCompare(b)),
    [models],
  );
  const visibleModels = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return models.filter(model => {
      const matchesSearch =
        !needle ||
        `${model.name} ${model.id} ${model.publisher} ${model.description}`.toLowerCase().includes(needle);
      const matchesCapability =
        capabilityFilter === 'all' || model.capabilities.includes(capabilityFilter as RadarModel['capabilities'][number]);
      const matchesPublisher = publisherFilter === 'all' || model.publisher === publisherFilter;
      return matchesSearch && matchesCapability && matchesPublisher;
    });
  }, [capabilityFilter, models, publisherFilter, search]);

  if (radarQuery.isLoading || providersQuery.isLoading) return <RadarSkeleton />;
  if (radarQuery.isError || providersQuery.isError) {
    return <RadarError onRetry={() => { void radarQuery.refetch(); void providersQuery.refetch(); }} />;
  }

  const hasModels = models.length > 0;
  const connectedProviders = providers.filter(provider => provider.isActive && provider.status === 'connected').length;

  return (
    <div className="mx-auto max-w-6xl animate-rise" data-testid="page-radar">
      <div className="mb-9 flex flex-col justify-between gap-5 md:flex-row md:items-end">
        <div>
          <div className="mb-3 flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-[.2em] text-primary">
            <span className="h-px w-6 bg-primary" />
            Radar / 06
          </div>
          <h1 className="text-4xl font-semibold tracking-[-.04em] text-balance md:text-5xl">Señal pública para tu routing.</h1>
          <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">
            Una lectura puntual del catálogo de OpenRouter para encontrar modelos publicados con precio cero y contrastarlos con las rutas que ya tienes conectadas.
          </p>
        </div>
        <button
          type="button"
          onClick={() => { void radarQuery.refetch(); void providersQuery.refetch(); }}
          disabled={radarQuery.isFetching || providersQuery.isFetching}
          data-testid="button-refresh-radar"
          className="inline-flex items-center justify-center gap-2 rounded-lg border border-border bg-card px-4 py-3 text-sm font-semibold hover:bg-muted disabled:opacity-60"
        >
          <RefreshCw size={15} className={radarQuery.isFetching ? 'animate-spin' : ''} />
          Actualizar señal
        </button>
      </div>

      <section className="relative overflow-hidden border border-sidebar-border bg-sidebar p-6 text-sidebar-foreground md:p-7" data-testid="section-radar-observation">
        <div className="absolute -right-20 -top-24 h-64 w-64 rounded-full border border-sidebar-primary/15" />
        <div className="absolute -right-4 -top-8 h-36 w-36 rounded-full border border-sidebar-primary/20" />
        <div className="relative grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
          <div>
            <div className="flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[.16em] text-sidebar-foreground/50">
              <span className="inline-flex items-center gap-1.5 text-sidebar-primary">
                <span className="h-1.5 w-1.5 rounded-full bg-sidebar-primary" />
                Fuente: {catalog?.source ?? 'openrouter'}
              </span>
              <span>·</span>
              <span data-testid="text-radar-checked-at">Lectura {catalog ? formatRadarDate(catalog.checkedAt) : 'no disponible'}</span>
            </div>
            <h2 className="mt-5 max-w-2xl text-2xl font-semibold tracking-[-.03em] md:text-3xl">
              El catálogo se consulta. El tráfico no se toca.
            </h2>
            <p className="mt-3 max-w-xl text-sm leading-6 text-sidebar-foreground/60">
              Esta superficie es solo lectura: no envía prompts, no ejecuta inferencias y no cambia ninguna configuración de Router IA.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-x-8 gap-y-4 border-t border-sidebar-border pt-5 lg:border-l lg:border-t-0 lg:pl-8 lg:pt-0">
            <div>
              <div className="font-mono text-2xl text-sidebar-primary" data-testid="text-radar-total">{catalog?.totalModels ?? 0}</div>
              <div className="mt-1 text-[10px] uppercase tracking-[.12em] text-sidebar-foreground/45">modelos revisados</div>
            </div>
            <div>
              <div className="font-mono text-2xl text-sidebar-primary" data-testid="text-radar-zero-cost">{catalog?.zeroCostModels ?? 0}</div>
              <div className="mt-1 text-[10px] uppercase tracking-[.12em] text-sidebar-foreground/45">precio cero publicado</div>
            </div>
          </div>
        </div>
      </section>

      {!hasModels ? (
        <section className="mt-6 border border-dashed border-border bg-card px-6 py-14 text-center" data-testid="empty-radar-catalog">
          <span className="mx-auto inline-flex rounded-xl bg-muted p-3 text-primary"><Search size={21} /></span>
          <h2 className="mt-4 text-xl font-semibold">No hay entradas de precio cero</h2>
          <p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-muted-foreground">
            La consulta terminó correctamente, pero el catálogo no devolvió modelos cuyos campos de precio publicados sean exactamente cero. No se mostrarán filas inventadas.
          </p>
          <p className="mt-4 font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground">
            Próxima lectura disponible con “Actualizar señal”
          </p>
        </section>
      ) : (
        <>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="border border-border bg-card p-5" data-testid="card-radar-stat-visible">
              <div className="flex items-start justify-between"><span className="field-label">Coincidencias visibles</span><Search size={16} className="text-primary" /></div>
              <div className="mt-6 text-3xl font-semibold tracking-[-.04em]" data-testid="text-radar-visible-count">{visibleModels.length}</div>
              <div className="mt-2 text-xs text-muted-foreground">de {models.length} entradas sin coste publicado</div>
            </div>
            <div className="border border-border bg-card p-5" data-testid="card-radar-stat-publishers">
              <div className="flex items-start justify-between"><span className="field-label">Publicadores</span><Database size={16} className="text-secondary" /></div>
              <div className="mt-6 text-3xl font-semibold tracking-[-.04em]" data-testid="text-radar-publisher-count">{publishers.length}</div>
              <div className="mt-2 text-xs text-muted-foreground">presentes en esta observación</div>
            </div>
            <div className="border border-border bg-card p-5" data-testid="card-radar-stat-tested">
              <div className="flex items-start justify-between"><span className="field-label">Rutas conectadas</span><ShieldCheck size={16} className="text-primary" /></div>
              <div className="mt-6 text-3xl font-semibold tracking-[-.04em]" data-testid="text-radar-connected-count">{connectedProviders}</div>
              <div className="mt-2 text-xs text-muted-foreground">capacidades probadas en Router</div>
            </div>
          </div>

          <CapabilityGapTable models={models} providers={providers} />

          <section className="mt-6 border border-border bg-card" data-testid="section-radar-models">
            <div className="flex flex-col gap-4 border-b border-border px-5 py-5 md:px-6">
              <div className="flex flex-col justify-between gap-3 md:flex-row md:items-end">
                <div>
                  <div className="flex items-center gap-2">
                    <Search size={17} className="text-primary" />
                    <h2 className="font-semibold">Catálogo de precio cero</h2>
                  </div>
                  <p className="mt-1 text-xs leading-5 text-muted-foreground">
                    Solo aparecen entradas con todos los precios publicados exactamente en cero.
                  </p>
                </div>
                {(search || capabilityFilter !== 'all' || publisherFilter !== 'all') && (
                  <button
                    type="button"
                    onClick={() => { setSearch(''); setCapabilityFilter('all'); setPublisherFilter('all'); }}
                    data-testid="button-clear-radar-filters"
                    className="inline-flex items-center gap-1.5 self-start text-xs font-semibold text-primary hover:underline"
                  >
                    <X size={14} /> Limpiar filtros
                  </button>
                )}
              </div>
              <div className="grid gap-3 md:grid-cols-[1.4fr_1fr_1fr]">
                <label className="relative block">
                  <span className="sr-only">Buscar modelos</span>
                  <Search size={15} className="pointer-events-none absolute left-3 top-3.5 text-muted-foreground" />
                  <input
                    type="search"
                    value={search}
                    onChange={event => setSearch(event.target.value)}
                    placeholder="Buscar por modelo, publicador o ID"
                    data-testid="input-radar-search"
                    className="field-input !mt-0 pl-9"
                  />
                </label>
                <label className="block">
                  <span className="sr-only">Filtrar por capacidad</span>
                  <select value={capabilityFilter} onChange={event => setCapabilityFilter(event.target.value)} data-testid="select-radar-capability" className="field-input !mt-0">
                    <option value="all">Todas las capacidades</option>
                    {capabilities.map(capability => <option key={capability} value={capability}>{capabilityLabels[capability] ?? capability}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="sr-only">Filtrar por publicador</span>
                  <select value={publisherFilter} onChange={event => setPublisherFilter(event.target.value)} data-testid="select-radar-publisher" className="field-input !mt-0">
                    <option value="all">Todos los publicadores</option>
                    {publishers.map(publisher => <option key={publisher} value={publisher}>{publisher}</option>)}
                  </select>
                </label>
              </div>
            </div>
            {visibleModels.length === 0 ? (
              <div className="px-6 py-14 text-center" data-testid="empty-radar-filtered">
                <span className="mx-auto inline-flex rounded-xl bg-muted p-3 text-muted-foreground"><Search size={20} /></span>
                <h3 className="mt-4 text-base font-semibold">No hay coincidencias</h3>
                <p className="mt-1 text-sm text-muted-foreground">Prueba con otro término o limpia los filtros de Radar.</p>
              </div>
            ) : (
              <div>{visibleModels.map((model, index) => <RadarModelRow key={model.id} model={model} index={index} />)}</div>
            )}
            <div className="flex items-start gap-2 border-t border-border bg-muted/30 px-5 py-4 text-[11px] leading-5 text-muted-foreground md:px-6">
              <CircleHelp size={14} className="mt-0.5 shrink-0 text-secondary-foreground" />
              <span>
                El precio es una observación puntual del catálogo, verificada en la fecha indicada. No garantiza que el precio futuro permanezca sin cambios.
              </span>
            </div>
          </section>
        </>
      )}

      <div className="mt-6 flex flex-col gap-4 border border-border bg-card p-5 sm:flex-row sm:items-center sm:justify-between" data-testid="section-radar-next-step">
        <div className="flex items-start gap-3">
          <span className="rounded-lg bg-primary/10 p-2 text-primary"><ShieldCheck size={17} /></span>
          <div>
            <h2 className="text-sm font-semibold">Radar informa; Router decide.</h2>
            <p className="mt-1 max-w-xl text-xs leading-5 text-muted-foreground">
              Usa esta lectura para orientar tu revisión. La selección de rutas, sus pruebas y el tráfico de tus apps siguen viviendo en Router IA.
            </p>
          </div>
        </div>
        <Link href="/providers" data-testid="link-radar-providers" className="inline-flex shrink-0 items-center gap-2 rounded-lg border border-border px-3.5 py-2.5 text-xs font-semibold hover:bg-muted">
          Revisar proveedores <ArrowRight size={14} />
        </Link>
      </div>
    </div>
  );
}