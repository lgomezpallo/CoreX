import { useEffect, useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Activity,
  AudioLines,
  Check,
  FileAudio,
  Loader2,
  Mic,
  Play,
  RefreshCw,
  Square,
  TriangleAlert,
} from "lucide-react";
import {
  getListRouterVoiceRunsQueryKey,
  useCreateRouterSpeechRun,
  useListProviders,
  useListRadarModels,
  useListRouterVoiceRuns,
  useTranscribeRouterAudio,
  type Provider,
} from "@workspace/api-client-react";
import { Link } from "wouter";

type AudioFormat =
  | "flac"
  | "mp3"
  | "mp4"
  | "mpeg"
  | "mpga"
  | "m4a"
  | "ogg"
  | "wav"
  | "webm";

const formatByExtension: Record<string, AudioFormat> = {
  flac: "flac",
  mp3: "mp3",
  mp4: "mp4",
  mpeg: "mpeg",
  mpga: "mpga",
  m4a: "m4a",
  ogg: "ogg",
  wav: "wav",
  webm: "webm",
};

const MAX_AUDIO_BYTES = 25 * 1024 * 1024;

function getAudioFormat(file: File): AudioFormat | null {
  const extension = file.name.split(".").pop()?.toLowerCase();
  return extension ? (formatByExtension[extension] ?? null) : null;
}

function formatDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "fecha no disponible"
    : new Intl.DateTimeFormat("es", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(date);
}

function formatBytes(value: number) {
  return value >= 1024 * 1024
    ? `${(value / (1024 * 1024)).toFixed(1)} MB`
    : `${Math.max(1, Math.round(value / 1024))} KB`;
}

function isOpenRouterProvider(provider: Provider) {
  if (provider.kind !== "openai-compatible" || !provider.baseUrl) return false;
  try {
    const url = new URL(provider.baseUrl);
    return (
      url.origin === "https://openrouter.ai" &&
      url.pathname.replace(/\/+$/, "") === "/api/v1"
    );
  } catch {
    return false;
  }
}

export default function VoicePage() {
  const queryClient = useQueryClient();
  const providersQuery = useListProviders();
  const radarQuery = useListRadarModels();
  const runsQuery = useListRouterVoiceRuns();
  const transcribe = useTranscribeRouterAudio();
  const saveSpeechRun = useCreateRouterSpeechRun();

  const providers = providersQuery.data ?? [];
  const openRouterProviders = providers.filter(isOpenRouterProvider);
  const transcriptionModels =
    radarQuery.data?.models.filter((model) =>
      model.capabilities.includes("transcription"),
    ) ?? [];

  const [providerId, setProviderId] = useState("");
  const [modelId, setModelId] = useState("");
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioError, setAudioError] = useState("");
  const [speechText, setSpeechText] = useState("");
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceURI, setVoiceURI] = useState("");
  const [speechStatus, setSpeechStatus] = useState<
    "idle" | "speaking" | "saved" | "error"
  >("idle");
  const [speechError, setSpeechError] = useState("");
  const startedAt = useRef(0);
  const cancellingSpeech = useRef(false);

  const selectedFileFormat = useMemo(
    () => (audioFile ? getAudioFormat(audioFile) : null),
    [audioFile],
  );
  const selectedVoice = voices.find((voice) => voice.voiceURI === voiceURI);

  useEffect(() => {
    if (!providerId && openRouterProviders[0]) {
      setProviderId(openRouterProviders[0].id);
    }
  }, [openRouterProviders, providerId]);

  useEffect(() => {
    if (
      !modelId ||
      !transcriptionModels.some((model) => model.id === modelId)
    ) {
      setModelId(transcriptionModels[0]?.id ?? "");
    }
  }, [modelId, transcriptionModels]);

  useEffect(() => {
    if (!("speechSynthesis" in window)) return;
    const updateVoices = () => {
      const localVoices = window.speechSynthesis
        .getVoices()
        .filter((voice) => voice.localService);
      setVoices(localVoices);
      if (!voiceURI && localVoices[0]) setVoiceURI(localVoices[0].voiceURI);
    };
    updateVoices();
    window.speechSynthesis.addEventListener("voiceschanged", updateVoices);
    return () => {
      window.speechSynthesis.removeEventListener("voiceschanged", updateVoices);
      window.speechSynthesis.cancel();
    };
  }, [voiceURI]);

  const submitTranscription = (event: React.FormEvent) => {
    event.preventDefault();
    setAudioError("");
    if (!audioFile || !selectedFileFormat || !providerId || !modelId) return;
    transcribe.mutate(
      {
        data: audioFile,
        params: {
          providerId,
          model: modelId,
          format: selectedFileFormat,
        },
      },
      {
        onSuccess: () => {
          void queryClient.invalidateQueries({
            queryKey: getListRouterVoiceRunsQueryKey(),
          });
        },
      },
    );
  };

  const chooseAudio = (file: File | null) => {
    setAudioError("");
    setAudioFile(file);
    if (!file) return;
    if (!getAudioFormat(file)) {
      setAudioFile(null);
      setAudioError(
        "Formato no admitido. Usa FLAC, MP3, MP4, MPEG, M4A, OGG, WAV o WEBM.",
      );
      return;
    }
    if (file.size > MAX_AUDIO_BYTES) {
      setAudioFile(null);
      setAudioError("El archivo supera el límite de 25 MB.");
    }
  };

  const recordSpeechRun = (
    text: string,
    voiceName: string,
    success: boolean,
    errorMessage?: string,
  ) => {
    saveSpeechRun.mutate(
      {
        data: {
          inputText: text,
          model: voiceName,
          success,
          latencyMs: Math.max(0, Math.round(performance.now() - startedAt.current)),
          ...(errorMessage ? { errorMessage } : {}),
        },
      },
      {
        onSuccess: () => {
          void queryClient.invalidateQueries({
            queryKey: getListRouterVoiceRunsQueryKey(),
          });
        },
      },
    );
  };

  const speak = () => {
    const text = speechText.trim();
    if (!text || !selectedVoice) return;
    setSpeechError("");
    setSpeechStatus("speaking");
    cancellingSpeech.current = false;
    startedAt.current = performance.now();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = selectedVoice;
    utterance.lang = selectedVoice.lang;
    utterance.onend = () => {
      setSpeechStatus("saved");
      recordSpeechRun(text, `Navegador · ${selectedVoice.name} (${selectedVoice.lang})`, true);
    };
    utterance.onerror = (event) => {
      if (cancellingSpeech.current && event.error === "canceled") return;
      const message = "El navegador no pudo reproducir la voz local.";
      setSpeechStatus("error");
      setSpeechError(message);
      recordSpeechRun(
        text,
        `Navegador · ${selectedVoice.name} (${selectedVoice.lang})`,
        false,
        message,
      );
    };
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeech = () => {
    cancellingSpeech.current = true;
    window.speechSynthesis.cancel();
    setSpeechStatus("idle");
  };

  const transcriptionError =
    transcribe.error instanceof Error ? transcribe.error.message : "";

  return (
    <div className="mx-auto max-w-6xl animate-rise space-y-7">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[.2em] text-primary">
            Laboratorio / Voz
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">
            Transcribe y escucha.
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
            La transcripción solo se envía a un modelo que siga verificado a $0.
            La síntesis usa una voz local del dispositivo. Router no guarda
            archivos de audio.
          </p>
        </div>
        <Link
          href="/radar"
          data-testid="link-voice-radar"
          className="inline-flex items-center gap-2 border border-border bg-card px-4 py-3 text-sm font-semibold hover:bg-muted"
        >
          <Activity size={15} /> Ver Radar
        </Link>
      </header>

      <div className="grid gap-5 xl:grid-cols-2">
        <section className="border border-border bg-card p-5 sm:p-6">
          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-primary/10 p-2.5 text-primary">
              <FileAudio size={19} />
            </span>
            <div>
              <h2 className="font-semibold">Transcripción a $0</h2>
              <p className="text-xs text-muted-foreground">
                El precio se comprueba de nuevo antes de enviar el audio.
              </p>
            </div>
          </div>

          {openRouterProviders.length === 0 ? (
            <div className="mt-5 rounded-xl border border-dashed border-border p-4">
              <p className="text-sm font-semibold">
                Falta conectar una cuenta de OpenRouter
              </p>
              <p className="mt-1 text-xs leading-5 text-muted-foreground">
                En Proveedores, agrega un endpoint compatible con OpenAI usando
                la URL <code>https://openrouter.ai/api/v1</code> y una clave
                guardada de forma cifrada. No se enviará audio hasta que pulses
                Transcribir.
              </p>
              <Link
                href="/providers"
                data-testid="link-voice-add-provider"
                className="mt-3 inline-flex rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground"
              >
                Ir a Proveedores
              </Link>
            </div>
          ) : (
            <form onSubmit={submitTranscription} className="mt-5 space-y-4">
              <label className="block">
                <span className="field-label">Conexión OpenRouter</span>
                <select
                  data-testid="select-voice-provider"
                  className="field-input"
                  value={providerId}
                  onChange={(event) => setProviderId(event.target.value)}
                >
                  {openRouterProviders.map((provider) => (
                    <option key={provider.id} value={provider.id}>
                      {provider.name}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="field-label">Modelo de entrada de audio</span>
                <select
                  data-testid="select-voice-model"
                  className="field-input"
                  value={modelId}
                  onChange={(event) => setModelId(event.target.value)}
                  disabled={transcriptionModels.length === 0}
                >
                  {transcriptionModels.map((model) => (
                    <option key={model.id} value={model.id}>
                      {model.name} · {model.id}
                    </option>
                  ))}
                </select>
                {radarQuery.data?.checkedAt && (
                  <span className="mt-1 block text-[11px] text-muted-foreground">
                    Catálogo consultado: {formatDate(radarQuery.data.checkedAt)}
                  </span>
                )}
              </label>

              <label className="block">
                <span className="field-label">Archivo de audio (máx. 25 MB)</span>
                <input
                  data-testid="input-voice-audio"
                  type="file"
                  accept=".flac,.mp3,.mp4,.mpeg,.mpga,.m4a,.ogg,.wav,.webm,audio/*"
                  onChange={(event) =>
                    chooseAudio(event.currentTarget.files?.[0] ?? null)
                  }
                  className="field-input file:mr-3 file:rounded-md file:border-0 file:bg-muted file:px-3 file:py-2 file:text-xs file:font-semibold"
                />
                {audioFile && (
                  <span className="mt-1 block text-[11px] text-muted-foreground">
                    {audioFile.name} · {formatBytes(audioFile.size)}
                  </span>
                )}
              </label>

              {audioError && (
                <p
                  data-testid="status-voice-file-error"
                  className="rounded-lg bg-destructive/10 p-3 text-xs text-destructive"
                >
                  {audioError}
                </p>
              )}

              {transcribe.isError && (
                <p
                  data-testid="status-voice-transcription-error"
                  className="flex items-start gap-2 rounded-lg bg-destructive/10 p-3 text-xs leading-5 text-destructive"
                >
                  <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                  {transcriptionError || "No se pudo transcribir el audio."}
                </p>
              )}

              {transcribe.data && (
                <div
                  data-testid="result-voice-transcription"
                  className="rounded-xl border border-primary/25 bg-primary/5 p-4"
                >
                  <div className="flex items-center gap-2 text-xs font-semibold text-primary">
                    <Check size={14} /> Transcripción guardada
                  </div>
                  <p className="mt-3 whitespace-pre-wrap text-sm leading-6">
                    {transcribe.data.transcript}
                  </p>
                  <p className="mt-3 font-mono text-[10px] text-muted-foreground">
                    {transcribe.data.model} · {transcribe.data.latencyMs} ms ·
                    precio revisado {formatDate(transcribe.data.pricingVerifiedAt)}
                  </p>
                </div>
              )}

              <div className="rounded-lg bg-muted/60 p-3 text-[11px] leading-5 text-muted-foreground">
                El archivo permanece en memoria durante la solicitud y se
                descarta al terminar. Solo se guarda la transcripción, el modelo,
                el tamaño, el formato y la latencia. Si el precio dejó de ser
                cero, el servidor rechaza la solicitud antes de enviarla.
              </div>

              <button
                type="submit"
                disabled={
                  !audioFile ||
                  !selectedFileFormat ||
                  !providerId ||
                  !modelId ||
                  transcribe.isPending ||
                  transcriptionModels.length === 0
                }
                data-testid="button-voice-transcribe"
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
              >
                {transcribe.isPending ? (
                  <Loader2 size={15} className="animate-spin" />
                ) : (
                  <AudioLines size={15} />
                )}
                {transcribe.isPending ? "Transcribiendo..." : "Transcribir"}
              </button>
            </form>
          )}
        </section>

        <section className="border border-border bg-card p-5 sm:p-6">
          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-secondary/20 p-2.5 text-secondary-foreground">
              <Mic size={19} />
            </span>
            <div>
              <h2 className="font-semibold">Síntesis de voz local</h2>
              <p className="text-xs text-muted-foreground">
                Solo voces marcadas como locales por el navegador.
              </p>
            </div>
          </div>

          <div className="mt-5 space-y-4">
            <label className="block">
              <span className="field-label">Texto</span>
              <textarea
                data-testid="input-voice-speech-text"
                value={speechText}
                onChange={(event) => setSpeechText(event.target.value)}
                maxLength={4000}
                rows={5}
                placeholder="Escribe una frase breve para escucharla…"
                className="field-input min-h-32 resize-y"
              />
              <span className="mt-1 block text-right text-[11px] text-muted-foreground">
                {speechText.length}/4000
              </span>
            </label>

            {voices.length > 0 ? (
              <label className="block">
                <span className="field-label">Voz del dispositivo</span>
                <select
                  data-testid="select-voice-local"
                  className="field-input"
                  value={voiceURI}
                  onChange={(event) => setVoiceURI(event.target.value)}
                >
                  {voices.map((voice) => (
                    <option key={voice.voiceURI} value={voice.voiceURI}>
                      {voice.name} · {voice.lang}
                    </option>
                  ))}
                </select>
              </label>
            ) : (
              <div
                data-testid="status-voice-local-unavailable"
                className="rounded-lg border border-dashed border-border p-3 text-xs leading-5 text-muted-foreground"
              >
                Este navegador no informó voces locales. No se usarán voces de
                red ni se enviará el texto a un servicio externo.
              </div>
            )}

            {speechError && (
              <p
                data-testid="status-voice-speech-error"
                className="rounded-lg bg-destructive/10 p-3 text-xs text-destructive"
              >
                {speechError}
              </p>
            )}
            {speechStatus === "saved" && (
              <p
                data-testid="status-voice-speech-saved"
                className="text-xs text-primary"
              >
                Reproducción finalizada; el texto y la voz quedaron registrados.
              </p>
            )}
            {saveSpeechRun.isError && (
              <p className="text-xs text-destructive">
                No se pudo guardar el registro de la reproducción.
              </p>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={speak}
                disabled={
                  !speechText.trim() ||
                  !selectedVoice ||
                  speechStatus === "speaking"
                }
                data-testid="button-voice-speak"
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Play size={15} />
                {speechStatus === "speaking" ? "Reproduciendo..." : "Escuchar"}
              </button>
              <button
                type="button"
                onClick={stopSpeech}
                disabled={speechStatus !== "speaking"}
                data-testid="button-voice-stop"
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-border px-4 py-3 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Square size={14} /> Detener
              </button>
            </div>

            <div className="rounded-lg bg-muted/60 p-3 text-[11px] leading-5 text-muted-foreground">
              El audio se reproduce directamente en el equipo y no se sube ni se
              conserva. Se guarda el texto escrito y el nombre de la voz local
              para que puedas revisar la prueba después.
            </div>
          </div>
        </section>
      </div>

      <section className="border border-border bg-card p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">
              Historial
            </p>
            <h2 className="mt-1 text-lg font-semibold">Últimos resultados</h2>
          </div>
          <button
            type="button"
            onClick={() => void runsQuery.refetch()}
            disabled={runsQuery.isFetching}
            data-testid="button-refresh-voice-runs"
            className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-xs font-semibold hover:bg-muted disabled:opacity-50"
          >
            <RefreshCw
              size={13}
              className={runsQuery.isFetching ? "animate-spin" : ""}
            />
            Actualizar
          </button>
        </div>

        {runsQuery.isLoading ? (
          <div className="mt-5 flex items-center gap-2 text-xs text-muted-foreground">
            <Loader2 size={14} className="animate-spin" /> Cargando historial…
          </div>
        ) : runsQuery.isError ? (
          <p className="mt-5 text-xs text-destructive">
            No se pudo cargar el historial. Vuelve a intentarlo.
          </p>
        ) : runsQuery.data?.length ? (
          <div className="mt-4 divide-y divide-border">
            {runsQuery.data.map((run) => (
              <article
                key={run.id}
                data-testid={`card-voice-run-${run.id}`}
                className="grid gap-2 py-4 sm:grid-cols-[150px_1fr_auto]"
              >
                <div>
                  <div className="text-xs font-semibold">
                    {run.operation === "transcription"
                      ? "Transcripción"
                      : "Síntesis local"}
                  </div>
                  <div className="mt-1 text-[10px] text-muted-foreground">
                    {formatDate(run.createdAt)}
                  </div>
                </div>
                <p className="whitespace-pre-wrap text-xs leading-5">
                  {run.operation === "transcription"
                    ? run.responseText || run.errorMessage || "Sin resultado"
                    : run.inputText || "Sin texto"}
                </p>
                <div className="font-mono text-[10px] text-muted-foreground">
                  {run.model} · {run.latencyMs} ms
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="mt-5 rounded-xl border border-dashed border-border p-6 text-center text-xs text-muted-foreground">
            Todavía no hay resultados de voz guardados.
          </div>
        )}
      </section>
    </div>
  );
}