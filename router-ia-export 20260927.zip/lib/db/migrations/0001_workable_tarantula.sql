CREATE TABLE "router_provider_runs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" text NOT NULL,
	"provider_id" uuid,
	"provider_name" text NOT NULL,
	"operation" text NOT NULL,
	"model" text NOT NULL,
	"input_text" text,
	"response_text" text,
	"success" boolean NOT NULL,
	"latency_ms" integer NOT NULL,
	"request_mime_type" text,
	"request_bytes" integer,
	"response_mime_type" text,
	"response_bytes" integer,
	"error_message" text,
	"provider_status_code" integer,
	"input_tokens" integer,
	"output_tokens" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "router_provider_runs" ADD CONSTRAINT "router_provider_runs_provider_id_ai_providers_id_fk" FOREIGN KEY ("provider_id") REFERENCES "public"."ai_providers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "router_provider_runs_user_created_idx" ON "router_provider_runs" USING btree ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "router_provider_runs_provider_created_idx" ON "router_provider_runs" USING btree ("provider_id","created_at");